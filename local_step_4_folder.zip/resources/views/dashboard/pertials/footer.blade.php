<footer class="footer">
    <div class="text-center mt-3">
        <a class="sidebar-brand brand-logo-mini pl-4 pt-3" href="{{ route('backoffice.home') }}">
            <img src="{{ asset('backend/unipos_logo.png') }}" height="30px" alt="UNIPOS LOGO" /></a>
        <span class="pl-4">Copyright © 2022</span>
        <a href="https://www.ussbd.com/" target="_blank">UNIPOS</a> by <a href="https://www.ussbd.com/"
            target="_blank"> Unicorn Software and
            Solutions Ltd.</a></span>
            <a class="sidebar-brand brand-logo-mini pl-4 pt-3" href="https://www.ussbd.com/">
            <img src="{{ asset('backend/unicorn_logo.png') }}" height="50px" alt="Unicorn Logo" /></a>
    </div>
</footer>
