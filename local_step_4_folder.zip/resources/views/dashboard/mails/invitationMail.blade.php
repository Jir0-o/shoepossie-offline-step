<!DOCTYPE html>
<html>
<head>
<style>
.note {
  font-size: 120%;
  color: red;
}
</style>
</head>
<body>

<h1>{{ $details['title'] }}</h1>
<p>{{ $details['body'] }}</p>
<p>Thank You!!</p>

</body>
</html>