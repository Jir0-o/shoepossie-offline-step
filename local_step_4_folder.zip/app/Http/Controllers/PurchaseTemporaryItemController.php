<?php

namespace App\Http\Controllers;

use App\Models\PurchaseTemporaryItem;
use Illuminate\Http\Request;

class PurchaseTemporaryItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PurchaseTemporaryItem  $purchaseTemporaryItem
     * @return \Illuminate\Http\Response
     */
    public function show(PurchaseTemporaryItem $purchaseTemporaryItem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PurchaseTemporaryItem  $purchaseTemporaryItem
     * @return \Illuminate\Http\Response
     */
    public function edit(PurchaseTemporaryItem $purchaseTemporaryItem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PurchaseTemporaryItem  $purchaseTemporaryItem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PurchaseTemporaryItem $purchaseTemporaryItem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PurchaseTemporaryItem  $purchaseTemporaryItem
     * @return \Illuminate\Http\Response
     */
    public function destroy(PurchaseTemporaryItem $purchaseTemporaryItem)
    {
        //
    }
}
